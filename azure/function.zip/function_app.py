import json
import uuid
import os
from datetime import datetime
import azure.functions as func
from azure.data.tables import TableServiceClient

app = func.FunctionApp()

# POST endpoint - receives data from Pico
@app.route(route="sensor-data", methods=["POST"])
def http_trigger(req: func.HttpRequest) -> func.HttpResponse:
    try:
        req_body = req.get_json()

        if not req_body:
            return func.HttpResponse(
                "Invalid request: Expected JSON data",
                status_code=400
            )

        table_service = TableServiceClient.from_connection_string(
            os.environ["AzureWebJobsStorage"]
        )

        try:
            table_service.create_table_if_not_exists("SensorReadings")
        except Exception:
            pass

        table_client = table_service.get_table_client("SensorReadings")

        entity = {
            "PartitionKey": req_body.get("ID", "unknown_device"),
            "RowKey": str(uuid.uuid4()),
            "DateTime": datetime.utcnow().isoformat(),
            "SoilTemp_C": float(req_body.get("Soil Temperature (C)", 0)),
            "SoilMoisture_Percent": float(req_body.get("Soil Moisture (%)", 0)),
            "IR_Temp_C": float(req_body.get("IR Temperature (C)", 0)),
            "Rainfall_Total_mm": float(req_body.get("Rainfall Total (mm)", 0)),
            "Rainfall_Hourly_mm": float(req_body.get("Rainfall Hourly (mm)", 0)),
            "DeviceID": req_body.get("ID", "unknown"),
            "SoftwareDate": req_body.get("software_date", ""),
            "Version": req_body.get("version", "")
        }

        table_client.create_entity(entity)

        return func.HttpResponse(
            json.dumps({"status": "success", "message": "Data ingested successfully"}),
            status_code=200,
            headers={"Content-Type": "application/json"}
        )

    except ValueError as e:
        return func.HttpResponse(
            json.dumps({"status": "error", "message": f"Invalid JSON data: {str(e)}"}),
            status_code=400,
            headers={"Content-Type": "application/json"}
        )
    except Exception as e:
        return func.HttpResponse(
            json.dumps({"status": "error", "message": f"Server error: {str(e)}"}),
            status_code=500,
            headers={"Content-Type": "application/json"}
        )


# GET endpoint - returns sensor data for dashboard
@app.route(route="sensor-data", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def get_sensor_data(req: func.HttpRequest) -> func.HttpResponse:
    try:
        table_service = TableServiceClient.from_connection_string(
            os.environ["AzureWebJobsStorage"]
        )
        table_client = table_service.get_table_client("SensorReadings")

        # Get query parameters
        device_id = req.params.get('device_id')
        limit = int(req.params.get('limit', 50))

        # Query entities, ordered by timestamp descending
        if device_id:
            filter_query = f"PartitionKey eq '{device_id}'"
            entities = list(table_client.query_entities(filter_query))
        else:
            entities = list(table_client.list_entities())

        # Sort by DateTime descending and limit
        entities.sort(key=lambda x: x.get('DateTime', ''), reverse=True)
        entities = entities[:limit]

        # Get the latest reading for live display
        latest = entities[0] if entities else None

        # Build response matching Pico dashboard format
        response = {
            "live": {
                "soil_temp_c": latest.get("SoilTemp_C", 0) if latest else 0,
                "soil_temp_f": (latest.get("SoilTemp_C", 0) * 9/5 + 32) if latest else 32,
                "soil_moisture": latest.get("SoilMoisture_Percent", 0) if latest else 0,
                "ir_object_temp_c": latest.get("IR_Temp_C", 0) if latest else 0,
                "ir_object_temp_f": (latest.get("IR_Temp_C", 0) * 9/5 + 32) if latest else 32,
                "rainfall_hourly": latest.get("Rainfall_Hourly_mm", 0) if latest else 0,
                "rainfall_total": latest.get("Rainfall_Total_mm", 0) if latest else 0
            },
            "status": {
                "rainfall_available": True,
                "mlx90614_available": True,
                "ds18b20_available": True,
                "soil_moisture_available": True
            },
            "system": {
                "device_model": "Azure Cloud",
                "uptime_str": "Cloud Service",
                "memory_percent": 0,
                "device_id": latest.get("DeviceID", "unknown") if latest else "unknown",
                "version": latest.get("Version", "3.0") if latest else "3.0"
            },
            "history": {
                "timestamps": [e.get("DateTime", "")[-8:-3] for e in reversed(entities[:24])],
                "soil_temps": [e.get("SoilTemp_C", 0) for e in reversed(entities[:24])],
                "soil_moistures": [e.get("SoilMoisture_Percent", 0) for e in reversed(entities[:24])],
                "ir_temps": [e.get("IR_Temp_C", 0) for e in reversed(entities[:24])],
                "rainfall": [e.get("Rainfall_Hourly_mm", 0) for e in reversed(entities[:24])]
            },
            "readings_count": len(entities),
            "last_updated": latest.get("DateTime", "") if latest else ""
        }

        return func.HttpResponse(
            json.dumps(response),
            status_code=200,
            headers={
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "GET, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type"
            }
        )

    except Exception as e:
        return func.HttpResponse(
            json.dumps({"status": "error", "message": str(e)}),
            status_code=500,
            headers={
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            }
        )


# OPTIONS endpoint for CORS preflight
@app.route(route="sensor-data", methods=["OPTIONS"], auth_level=func.AuthLevel.ANONYMOUS)
def options_sensor_data(req: func.HttpRequest) -> func.HttpResponse:
    return func.HttpResponse(
        "",
        status_code=200,
        headers={
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type"
        }
    )
